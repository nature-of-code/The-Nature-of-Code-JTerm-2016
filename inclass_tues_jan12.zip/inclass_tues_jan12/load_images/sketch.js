var img;

var x = 0;
function preload() {
  img = loadImage('images/cat.png');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255, 0, 0);
  
  var a = map(mouseX, 0, width, 0, 255);
  tint(0, 0, 255, a);
  image(img, 0, 0);
  
  //background(50);
  //image(img, x, 0, mouseX, mouseY)
  //x = x + 1;
}