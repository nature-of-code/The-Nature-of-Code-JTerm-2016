var parrot;

function preload() {
  parrot = loadImage('parrot1.jpg');
}

var bubbles = [];

function setup() {
  createCanvas(360, 330);
}

function mouseDragged() {
  bubbles.push(new Bubble(mouseX, mouseY));
}

function draw() {
  parrot.loadPixels();
  //background(0);
  for (var i = 0; i < bubbles.length; i++) {
    bubbles[i].move();
    bubbles[i].display();
  }
}

function Bubble(x, y) {
  this.x = x;
  this.y = y;

  this.display = function() {
    //var index = floor(this.x) + floor(this.y)*parrot.width;
    //var col = parrot.pixels[index];
    
    var col = parrot.get(this.x, this.y);
    var r = red(col);
    var g = green(col);
    var b = blue(col);
    noStroke();
    fill(r,g,b, 50);
    ellipse(this.x, this.y, 24, 24);
  }

  this.move = function() {
    this.x = this.x + random(-5, 5);
    this.y = this.y + random(-5, 5);

  }
}