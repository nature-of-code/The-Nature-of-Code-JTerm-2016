var parrot;

var x = 120;
var y = 100;

function preload() {
  parrot = loadImage('parrot1.jpg');  
}

function setup() {
  createCanvas(360, 330);
}

function draw() {
  //image(parrot,0,0);
  var col = parrot.get(mouseX, mouseY);
  var r = red(col);
  var g = green(col);
  var b = blue(col);
  noStroke();
  fill(r, g, b, 50);
  ellipse(mouseX, mouseY, 20, 20);
}